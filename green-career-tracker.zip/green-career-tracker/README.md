# 🌿 Green Career Tracker

Your personal dashboard for tracking the pivot to a sustainable residential firm.

## What this is
A single-page web app that tracks 17 companies across 4 tiers, with:
- Per-company to-do lists (actions + skills)
- Status tracking (Not yet → Applied → Interviewing → Offer)
- Connection and notes fields
- Progress bars
- Table and Board views
- Export/Import to preserve your data across updates

## How to update it
1. Claude gives you a new `index.html`
2. Go to your GitHub repo → click `index.html` → click the pencil icon (Edit)
3. Select all, paste the new code, click **Commit changes**
4. Netlify auto-deploys in ~30 seconds
5. Refresh your browser — done

Your data is stored in your browser's localStorage and is never touched by updates.

## How to back up your data
Click **⬇ Export data** in the app → download the JSON file → store it safely.
When you need to restore: click **⬆ Import data** → paste the JSON.

## Adding companies yourself
Click **＋ Add company** in the app — fill in the form and save.
Or tell Claude and I'll add it to the master data in the next update.

## Tech stack
- Pure HTML/CSS/JavaScript — no frameworks, no build step
- localStorage for data persistence
- Netlify for hosting (free tier)
- GitHub for version control

## Version history
- v1.0 — Initial release with 17 companies
